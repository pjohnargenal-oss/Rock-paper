<?php
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_permission('reservations', 'view');

$pdo = db();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| RESERVATION SETTINGS
|--------------------------------------------------------------------------
*/

$RATES = [
    'day'   => 500,
    'week'  => 3000,
    'month' => 10000
];

$RATE_LABELS = [
    'day'   => 'Per Day',
    'week'  => 'Per Week',
    'month' => 'Per Month'
];

$MIN_DOWNPAYMENT_RATE = 0.30;

/*
|--------------------------------------------------------------------------
| HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

function reservationMoney($amount)
{
    return '₱' . number_format((float)$amount, 2);
}

function reservationDate($date)
{
    if (!$date) {
        return '—';
    }

    return date('M d, Y', strtotime($date));
}

function reservationDays($start, $end)
{
    $startDate = new DateTime($start);
    $endDate = new DateTime($end);

    return (int)$startDate->diff($endDate)->days;
}

function reservationBlocks($days, $unit)
{
    switch ($unit) {
        case 'day':
            return $days;

        case 'week':
            return (int)ceil($days / 7);

        case 'month':
            return (int)ceil($days / 30);

        default:
            return 0;
    }
}

function reservationTotal($days, $unit, $rates)
{
    $blocks = reservationBlocks($days, $unit);

    return $blocks * $rates[$unit];
}

function reservationEndDate($start, $unit, $value)
{
    /*
     * Legacy fallback only.
     * New reservations use requested_end_date.
     */

    $date = new DateTime($start);

    switch ($unit) {
        case 'day':
            $date->modify('+' . (int)$value . ' days');
            break;

        case 'week':
            $date->modify('+' . ((int)$value * 7) . ' days');
            break;

        case 'month':
            $date->modify('+' . (int)$value . ' months');
            break;

        default:
            $date->modify('+1 month');
    }

    return $date->format('Y-m-d');
}

function getReservationEnd($row)
{
    if (!empty($row['requested_end_date'])) {
        return $row['requested_end_date'];
    }

    if (empty($row['requested_move_in'])) {
        return null;
    }

    $unit = $row['duration_unit'] ?? 'month';
    $value = (int)($row['duration_value'] ?? 0);

    if ($value <= 0) {
        $value = max(1, (int)($row['requested_months'] ?? 1));
        $unit = 'month';
    }

    return reservationEndDate(
        $row['requested_move_in'],
        $unit,
        $value
    );
}

function tenantHasActiveReservation(
    PDO $pdo,
    $tenantId,
    $excludeReservationId = null
) {
    $sql = "
        SELECT COUNT(*)
        FROM reservations
        WHERE tenant_id = ?
          AND status IN ('Pending', 'Approved')
    ";

    $params = [$tenantId];

    if ($excludeReservationId) {
        $sql .= " AND reservation_id != ?";
        $params[] = $excludeReservationId;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return (int)$stmt->fetchColumn() > 0;
}

/*
|--------------------------------------------------------------------------
| ROOM CONFLICT CHECK
|--------------------------------------------------------------------------
| End date is exclusive.
| Example: Nov 5 to Nov 19 = 14 days.
| Another reservation can start on Nov 19.
|--------------------------------------------------------------------------
*/

function roomHasConflict(
    PDO $pdo,
    $roomId,
    $newStart,
    $newEnd,
    $excludeReservationId = null
) {
    $sql = "
        SELECT
            reservation_id,
            requested_move_in,
            requested_end_date,
            requested_months,
            duration_unit,
            duration_value,
            status
        FROM reservations
        WHERE room_id = ?
          AND status IN ('Pending', 'Approved')
    ";

    $params = [$roomId];

    if ($excludeReservationId) {
        $sql .= " AND reservation_id != ?";
        $params[] = $excludeReservationId;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($reservations as $reservation) {
        $existingStart = $reservation['requested_move_in'];
        $existingEnd = getReservationEnd($reservation);

        if (!$existingStart || !$existingEnd) {
            continue;
        }

        /*
         * Overlap condition:
         * New start < Existing end
         * New end > Existing start
         */

        if (
            $newStart < $existingEnd &&
            $newEnd > $existingStart
        ) {
            return true;
        }
    }

    return false;
}

function getPaymentStatus($paid, $total)
{
    if ($paid >= $total) {
        return 'Fully Paid';
    }

    if ($paid > 0) {
        return 'Partial';
    }

    return 'Unpaid';
}

function getStatusClass($status)
{
    $status = strtolower((string)$status);

    switch ($status) {
        case 'approved':
        case 'fully paid':
            return 'status-approved';

        case 'pending':
        case 'partial':
            return 'status-pending';

        case 'rejected':
        case 'cancelled':
        case 'unpaid':
            return 'status-rejected';

        default:
            return 'status-default';
    }
}

/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

$successMessage = '';
$errorMessage = '';

/*
|--------------------------------------------------------------------------
| CREATE RESERVATION / REVIEW RESERVATION
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!function_exists('verify_csrf')) {
            throw new Exception('CSRF verification helper is missing.');
        }

        verify_csrf();

        $action = $_POST['action'] ?? 'create';

        /*
        |--------------------------------------------------------------------------
        | CREATE RESERVATION
        |--------------------------------------------------------------------------
        */

        if ($action === 'create') {
            if (!can_access('reservations', 'add')) {
                throw new Exception(
                    'You do not have permission to add reservations.'
                );
            }

            $tenantId = (int)($_POST['tenant_id'] ?? 0);
            $roomId = (int)($_POST['room_id'] ?? 0);

            $startDate = trim($_POST['start_date'] ?? '');
            $endDate = trim($_POST['end_date'] ?? '');

            $unit = trim($_POST['duration_unit'] ?? '');
            $amountPaid = (float)($_POST['amount_paid'] ?? 0);

            $notes = trim($_POST['notes'] ?? '');

            if ($tenantId <= 0 || $roomId <= 0) {
                throw new Exception(
                    'Please select a tenant and room.'
                );
            }

            if (!$startDate || !$endDate) {
                throw new Exception(
                    'Please select both Start Date and End Date.'
                );
            }

            if (!isset($RATES[$unit])) {
                throw new Exception(
                    'Please select a valid pricing option.'
                );
            }

            $start = DateTime::createFromFormat('Y-m-d', $startDate);
            $end = DateTime::createFromFormat('Y-m-d', $endDate);

            if (
                !$start ||
                !$end ||
                $start->format('Y-m-d') !== $startDate ||
                $end->format('Y-m-d') !== $endDate
            ) {
                throw new Exception('Invalid reservation dates.');
            }

            if ($startDate >= $endDate) {
                throw new Exception(
                    'End Date must be later than Start Date.'
                );
            }

            $days = reservationDays($startDate, $endDate);

            if ($days < 1 || $days > 365) {
                throw new Exception(
                    'Reservation must be between 1 and 365 days.'
                );
            }

            $blocks = reservationBlocks($days, $unit);

            $totalAmount = reservationTotal(
                $days,
                $unit,
                $RATES
            );

            $downpaymentRequired = round(
                $totalAmount * $MIN_DOWNPAYMENT_RATE,
                2
            );

            $amountPaid = round($amountPaid, 2);

            if ($amountPaid < $downpaymentRequired) {
                throw new Exception(
                    'The required 30% downpayment is ' .
                    reservationMoney($downpaymentRequired) .
                    '. Please enter the amount received.'
                );
            }

            if ($amountPaid > $totalAmount) {
                throw new Exception(
                    'Amount paid cannot be greater than the total rental fee.'
                );
            }

            $balanceAmount = round(
                $totalAmount - $amountPaid,
                2
            );

            $paymentStatus = getPaymentStatus(
                $amountPaid,
                $totalAmount
            );

            /*
             * Lock room and tenant while checking availability.
             */

            $pdo->beginTransaction();

            $roomStmt = $pdo->prepare("
                SELECT room_id, status
                FROM rooms
                WHERE room_id = ?
                FOR UPDATE
            ");

            $roomStmt->execute([$roomId]);
            $room = $roomStmt->fetch(PDO::FETCH_ASSOC);

            if (!$room || $room['status'] !== 'Available') {
                throw new Exception(
                    'The selected room is not available.'
                );
            }

            $tenantStmt = $pdo->prepare("
                SELECT tenant_id, status
                FROM tenants
                WHERE tenant_id = ?
                FOR UPDATE
            ");

            $tenantStmt->execute([$tenantId]);
            $tenant = $tenantStmt->fetch(PDO::FETCH_ASSOC);

            if (!$tenant) {
                throw new Exception('Selected tenant was not found.');
            }

            if (
                isset($tenant['status']) &&
                strtolower($tenant['status']) !== 'active'
            ) {
                throw new Exception(
                    'Only active tenants can be selected.'
                );
            }

            if (tenantHasActiveReservation($pdo, $tenantId)) {
                throw new Exception(
                    'This tenant already has a Pending or Approved reservation.'
                );
            }

            if (
                roomHasConflict(
                    $pdo,
                    $roomId,
                    $startDate,
                    $endDate
                )
            ) {
                throw new Exception(
                    'The selected room already has a Pending or Approved reservation during these dates.'
                );
            }

            /*
             * requested_months is retained for compatibility
             * with the existing database structure.
             *
             * duration_value stores the number of pricing blocks.
             */

            $requestedMonths = (int)ceil($days / 30);

            $insert = $pdo->prepare("
                INSERT INTO reservations (
                    tenant_id,
                    room_id,
                    requested_move_in,
                    requested_end_date,
                    total_days,
                    requested_months,
                    duration_unit,
                    duration_value,
                    total_amount,
                    downpayment_required,
                    amount_paid,
                    balance_amount,
                    payment_status,
                    notes,
                    status
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending'
                )
            ");

            $insert->execute([
                $tenantId,
                $roomId,
                $startDate,
                $endDate,
                $days,
                $requestedMonths,
                $unit,
                $blocks,
                $totalAmount,
                $downpaymentRequired,
                $amountPaid,
                $balanceAmount,
                $paymentStatus,
                $notes
            ]);

            $pdo->commit();

            $successMessage = 'Reservation successfully created!';
        }

        /*
        |--------------------------------------------------------------------------
        | APPROVE / REJECT RESERVATION
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'review') {
            if (!can_access('reservations', 'edit')) {
                throw new Exception(
                    'You do not have permission to review reservations.'
                );
            }

            $reservationId = (int)(
                $_POST['reservation_id'] ?? 0
            );

            $decision = $_POST['decision'] ?? '';

            if (!in_array($decision, ['Approved', 'Rejected'], true)) {
                throw new Exception('Invalid reservation decision.');
            }

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                SELECT *
                FROM reservations
                WHERE reservation_id = ?
                FOR UPDATE
            ");

            $stmt->execute([$reservationId]);

            $reservation = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$reservation) {
                throw new Exception('Reservation not found.');
            }

            if ($reservation['status'] !== 'Pending') {
                throw new Exception(
                    'Only Pending reservations can be reviewed.'
                );
            }

            if ($decision === 'Approved') {
                $required = (float)(
                    $reservation['downpayment_required'] ?? 0
                );

                $paid = (float)(
                    $reservation['amount_paid'] ?? 0
                );

                if ($paid < $required) {
                    throw new Exception(
                        'Cannot approve this reservation. The 30% downpayment has not been completed.'
                    );
                }

                /*
                 * Lock room.
                 */

                $roomLock = $pdo->prepare("
                    SELECT room_id
                    FROM rooms
                    WHERE room_id = ?
                    FOR UPDATE
                ");

                $roomLock->execute([
                    $reservation['room_id']
                ]);

                if (!$roomLock->fetch()) {
                    throw new Exception('Room not found.');
                }

                $reservationEnd = getReservationEnd($reservation);

                if (!$reservationEnd) {
                    throw new Exception(
                        'Reservation End Date is missing.'
                    );
                }

                if (
                    roomHasConflict(
                        $pdo,
                        (int)$reservation['room_id'],
                        $reservation['requested_move_in'],
                        $reservationEnd,
                        $reservationId
                    )
                ) {
                    throw new Exception(
                        'Cannot approve. The room has another overlapping reservation.'
                    );
                }

                /*
                 * Check if tenant has another active reservation.
                 */

                if (
                    tenantHasActiveReservation(
                        $pdo,
                        (int)$reservation['tenant_id'],
                        $reservationId
                    )
                ) {
                    throw new Exception(
                        'Cannot approve. This tenant already has another Pending or Approved reservation.'
                    );
                }
            }

            $reviewedBy = $_SESSION['user_id'] ?? null;

            $update = $pdo->prepare("
                UPDATE reservations
                SET
                    status = ?,
                    reviewed_by = ?,
                    reviewed_at = NOW()
                WHERE reservation_id = ?
            ");

            $update->execute([
                $decision,
                $reviewedBy,
                $reservationId
            ]);

            $pdo->commit();

            $successMessage = (
                $decision === 'Approved'
                    ? 'Reservation approved successfully!'
                    : 'Reservation rejected successfully!'
            );
        }

        else {
            throw new Exception('Unknown reservation action.');
        }
    }

    catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $errorMessage = $e->getMessage();
    }
}

/*
|--------------------------------------------------------------------------
| GET TENANTS
|--------------------------------------------------------------------------
| Only tenants without Pending or Approved reservations are selectable.
|--------------------------------------------------------------------------
*/

$tenantStmt = $pdo->query("
    SELECT
        t.tenant_id,
        t.first_name,
        t.last_name,
        t.status
    FROM tenants t
    WHERE NOT EXISTS (
        SELECT 1
        FROM reservations r
        WHERE r.tenant_id = t.tenant_id
          AND r.status IN ('Pending', 'Approved')
    )
    ORDER BY t.last_name, t.first_name
");

$tenants = $tenantStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| GET AVAILABLE ROOMS
|--------------------------------------------------------------------------
*/

$roomStmt = $pdo->query("
    SELECT
        room_id,
        room_number,
        status
    FROM rooms
    WHERE status = 'Available'
    ORDER BY room_number
");

$rooms = $roomStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| GET RESERVATIONS
|--------------------------------------------------------------------------
*/

$reservationStmt = $pdo->query("
    SELECT
        r.*,
        t.first_name,
        t.last_name,
        rm.room_number,
        u.full_name AS reviewer_name
    FROM reservations r
    LEFT JOIN tenants t
        ON t.tenant_id = r.tenant_id
    LEFT JOIN rooms rm
        ON rm.room_id = r.room_id
    LEFT JOIN users u
        ON u.user_id = r.reviewed_by
    ORDER BY r.created_at DESC, r.reservation_id DESC
");

$reservations = $reservationStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| CALENDAR EVENTS
|--------------------------------------------------------------------------
*/

$calendarEvents = [];

foreach ($reservations as $row) {
    $startDate = $row['requested_move_in'];
    $endDate = getReservationEnd($row);

    if (!$startDate || !$endDate) {
        continue;
    }

    $status = $row['status'];

    if ($status === 'Approved') {
        $color = '#16a34a';
    } elseif ($status === 'Pending') {
        $color = '#d97706';
    } else {
        $color = '#dc2626';
    }

    $tenantName = trim(
        ($row['first_name'] ?? '') . ' ' .
        ($row['last_name'] ?? '')
    );

    $calendarEvents[] = [
        'id' => (string)$row['reservation_id'],
        'title' => 'Room ' . ($row['room_number'] ?? 'N/A')
            . ' - ' . $status,
        'start' => $startDate,
        'end' => $endDate,
        'backgroundColor' => $color,
        'borderColor' => $color,
        'extendedProps' => [
            'room' => $row['room_number'] ?? 'N/A',
            'roomId' => (int)$row['room_id'],
            'tenant' => $tenantName ?: 'Unknown Tenant',
            'status' => $status,
            'days' => (int)($row['total_days'] ?? 0),
            'start' => $startDate,
            'end' => $endDate,
            'total' => (float)($row['total_amount'] ?? 0),
            'paid' => (float)($row['amount_paid'] ?? 0),
            'balance' => (float)($row['balance_amount'] ?? 0),
            'paymentStatus' => $row['payment_status'] ?? 'Unpaid'
        ]
    ];
}

$calendarJson = json_encode(
    $calendarEvents,
    JSON_HEX_TAG |
    JSON_HEX_APOS |
    JSON_HEX_QUOT |
    JSON_HEX_AMP
);

if (!$calendarJson) {
    $calendarJson = '[]';
}

$pageTitle = 'Reservations';

require_once __DIR__ . '/../includes/header.php';
?>

<style>
/* RESERVATION PAGE */

.reservation-page {
    width: 100%;
}

.reservation-page .page-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 20px;
}

.reservation-page .page-heading h2 {
    margin: 0;
    font-size: 25px;
    font-weight: 700;
}

.reservation-page .page-heading p {
    margin: 5px 0 0;
    color: #64748b;
    font-size: 13px;
}

.reservation-card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 13px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(15, 23, 42, .04);
}

.reservation-card h3 {
    font-size: 17px;
    margin: 0 0 16px;
    font-weight: 700;
}

.reservation-form-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 15px;
}

.reservation-form-grid .full-width {
    grid-column: 1 / -1;
}

.reservation-page label {
    display: block;
    margin-bottom: 6px;
    font-size: 13px;
    font-weight: 600;
    color: #334155;
}

.reservation-page input,
.reservation-page select,
.reservation-page textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 14px;
    background: #fff;
    color: #0f172a;
}

.reservation-page input:focus,
.reservation-page select:focus,
.reservation-page textarea:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .10);
}

.reservation-page input[readonly] {
    background: #f8fafc;
}

.reservation-page textarea {
    resize: vertical;
    min-height: 85px;
}

.reservation-help {
    display: block;
    font-size: 11px;
    color: #64748b;
    margin-top: 5px;
}

.payment-summary {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
    margin-top: 18px;
}

.payment-summary .summary-item {
    padding: 14px;
    border: 1px solid #e2e8f0;
    background: #f8fafc;
    border-radius: 10px;
}

.payment-summary .summary-item small {
    display: block;
    color: #64748b;
    font-size: 11px;
    margin-bottom: 7px;
}

.payment-summary .summary-item strong {
    font-size: 18px;
    color: #0f172a;
    overflow-wrap: anywhere;
}

.payment-summary .summary-item.downpayment {
    background: #fff7ed;
    border-color: #fed7aa;
}

.payment-summary .summary-item.balance {
    background: #eff6ff;
    border-color: #bfdbfe;
}

.pricing-info {
    padding: 13px 15px;
    background: #f8fafc;
    border-radius: 9px;
    margin-top: 15px;
    font-size: 12px;
    color: #475569;
    line-height: 1.8;
}

.reservation-actions {
    display: flex;
    gap: 9px;
    flex-wrap: wrap;
    margin-top: 18px;
}

.reservation-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: 8px;
    padding: 10px 16px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    transition: .2s ease;
}

.reservation-btn:hover {
    opacity: .88;
    transform: translateY(-1px);
}

.btn-primary {
    color: #fff;
    background: #2563eb;
}

.btn-success {
    color: #fff;
    background: #16a34a;
}

.btn-danger {
    color: #fff;
    background: #dc2626;
}

.btn-secondary {
    color: #334155;
    background: #e2e8f0;
}

.calendar-legend {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    margin-bottom: 14px;
    font-size: 12px;
    color: #475569;
}

.calendar-legend span {
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.legend-dot {
    width: 9px;
    height: 9px;
    border-radius: 50%;
    display: inline-block;
}

#reservationCalendar {
    width: 100%;
    min-height: 600px;
}

.fc .fc-toolbar-title {
    font-size: 19px;
    font-weight: 700;
}

.fc .fc-button {
    background: #2563eb;
    border-color: #2563eb;
    text-transform: capitalize;
    font-size: 12px;
}

.fc .fc-button:hover {
    background: #1d4ed8;
}

.fc .fc-daygrid-event {
    padding: 2px 4px;
    font-size: 11px;
    cursor: pointer;
}

.reservation-table-wrap {
    width: 100%;
    overflow-x: auto;
}

.reservation-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 1250px;
    font-size: 12px;
}

.reservation-table th,
.reservation-table td {
    padding: 11px 10px;
    border-bottom: 1px solid #e5e7eb;
    text-align: left;
    white-space: nowrap;
}

.reservation-table th {
    background: #f8fafc;
    color: #475569;
    font-weight: 700;
}

.reservation-table tbody tr:hover {
    background: #f8fafc;
}

.status-badge {
    display: inline-block;
    border-radius: 30px;
    padding: 5px 10px;
    font-size: 10px;
    font-weight: 700;
}

.status-approved {
    background: #dcfce7;
    color: #166534;
}

.status-pending {
    background: #fef3c7;
    color: #92400e;
}

.status-rejected {
    background: #fee2e2;
    color: #991b1b;
}

.status-default {
    background: #e2e8f0;
    color: #334155;
}

.review-buttons {
    display: flex;
    gap: 5px;
}

.review-buttons form {
    display: inline;
}

.review-buttons .reservation-btn {
    padding: 6px 9px;
    font-size: 11px;
}

.reservation-empty {
    text-align: center;
    color: #64748b;
    padding: 25px !important;
}

@media (max-width: 900px) {
    .reservation-form-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .payment-summary {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 600px) {
    .reservation-form-grid {
        grid-template-columns: 1fr;
    }

    .reservation-form-grid .full-width {
        grid-column: auto;
    }

    .payment-summary {
        grid-template-columns: 1fr 1fr;
    }

    .reservation-card {
        padding: 14px;
    }

    #reservationCalendar {
        min-height: 480px;
    }

    .fc .fc-toolbar {
        flex-direction: column;
        gap: 8px;
    }
}
</style>

<div class="reservation-page">

    <div class="page-heading">
        <div>
            <h2>Reservations</h2>
            <p>Manage tenant reservations, room availability, and rental payments.</p>
        </div>
    </div>

    <?php if ($successMessage): ?>
        <div id="reservationSuccess"
             data-message="<?= h($successMessage) ?>"></div>
    <?php endif; ?>

    <?php if ($errorMessage): ?>
        <div id="reservationError"
             data-message="<?= h($errorMessage) ?>"></div>
    <?php endif; ?>

    <!-- CREATE RESERVATION -->

    <?php if (can_access('reservations', 'add')): ?>

    <div class="reservation-card">

        <h3>Create New Reservation</h3>

        <form method="POST"
              id="reservationForm"
              autocomplete="off">

            <input type="hidden"
                   name="csrf_token"
                   value="<?= h(csrf_token()) ?>">

            <input type="hidden"
                   name="action"
                   value="create">

            <div class="reservation-form-grid">

                <div>
                    <label for="tenant_id">Tenant</label>

                    <select name="tenant_id"
                            id="tenant_id"
                            required>

                        <option value="">Select Tenant</option>

                        <?php foreach ($tenants as $tenant): ?>

                            <option value="<?= (int)$tenant['tenant_id'] ?>">
                                <?= h(
                                    $tenant['first_name'] . ' ' .
                                    $tenant['last_name']
                                ) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <small class="reservation-help">
                        Tenants with Pending or Approved reservations are excluded.
                    </small>
                </div>

                <div>
                    <label for="room_id">Room</label>

                    <select name="room_id"
                            id="room_id"
                            required>

                        <option value="">Select Room</option>

                        <?php foreach ($rooms as $room): ?>

                            <option value="<?= (int)$room['room_id'] ?>">
                                Room <?= h($room['room_number']) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <small class="reservation-help">
                        Room availability will be checked against the selected dates.
                    </small>
                </div>

                <div>
                    <label for="duration_unit">Pricing Option</label>

                    <select name="duration_unit"
                            id="duration_unit"
                            required>

                        <option value="day">Per Day - ₱500</option>
                        <option value="week">Per Week - ₱3,000</option>
                        <option value="month">Per Month - ₱10,000</option>

                    </select>
                </div>

                <div>
                    <label for="start_date">Start Date</label>

                    <input type="date"
                           name="start_date"
                           id="start_date"
                           required>

                </div>

                <div>
                    <label for="end_date">End Date</label>

                    <input type="date"
                           name="end_date"
                           id="end_date"
                           required>

                    <small class="reservation-help">
                        End Date is exclusive and is not counted as a stay day.
                    </small>
                </div>

                <div>
                    <label for="total_days_display">Total Days</label>

                    <input type="number"
                           id="total_days_display"
                           value="0"
                           readonly>

                </div>

                <div>
                    <label for="amount_paid">Amount Received (₱)</label>

                    <input type="number"
                           name="amount_paid"
                           id="amount_paid"
                           min="0"
                           step="0.01"
                           value="0"
                           required>

                    <small class="reservation-help">
                        Enter the actual payment received from the tenant.
                    </small>
                </div>

                <div class="full-width">
                    <label for="notes">Notes</label>

                    <textarea name="notes"
                              id="notes"
                              maxlength="500"
                              placeholder="Additional reservation details..."></textarea>
                </div>

            </div>

            <!-- PAYMENT SUMMARY -->

            <div class="payment-summary">

                <div class="summary-item">
                    <small>Total Rental Fee</small>
                    <strong id="totalAmountDisplay">₱0.00</strong>
                </div>

                <div class="summary-item downpayment">
                    <small>Required Downpayment (30%)</small>
                    <strong id="downpaymentDisplay">₱0.00</strong>
                </div>

                <div class="summary-item">
                    <small>Amount Received</small>
                    <strong id="amountPaidDisplay">₱0.00</strong>
                </div>

                <div class="summary-item balance">
                    <small>Remaining Balance</small>
                    <strong id="balanceDisplay">₱0.00</strong>
                </div>

            </div>

            <div class="pricing-info">
                <strong>Pricing guide</strong><br>
                Per Day: ₱500 per day<br>
                Per Week: ₱3,000 per 7-day block<br>
                Per Month: ₱10,000 per 30-day block<br>
                Required downpayment: 30% of the total rental fee.
            </div>

            <div id="availabilityMessage"
                 style="margin-top:12px;font-size:13px;font-weight:600;">
            </div>

            <div class="reservation-actions">

                <button type="submit"
                        class="reservation-btn btn-primary"
                        id="saveReservationBtn">

                    Save Reservation

                </button>

                <button type="reset"
                        class="reservation-btn btn-secondary"
                        id="resetReservationBtn">

                    Clear Form

                </button>

            </div>

        </form>

    </div>

    <?php endif; ?>

    <!-- RESERVATION CALENDAR -->

    <div class="reservation-card">

        <h3>Reservation Calendar</h3>

        <div class="calendar-legend">

            <span>
                <i class="legend-dot" style="background:#16a34a;"></i>
                Approved
            </span>

            <span>
                <i class="legend-dot" style="background:#d97706;"></i>
                Pending
            </span>

            <span>
                <i class="legend-dot" style="background:#dc2626;"></i>
                Rejected / Cancelled
            </span>

        </div>

        <div id="reservationCalendar"></div>

    </div>

    <!-- RESERVATION LIST -->

    <div class="reservation-card">

        <h3>Reservation Records</h3>

        <div class="reservation-table-wrap">

            <table class="reservation-table">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tenant</th>
                        <th>Room</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Total Days</th>
                        <th>Pricing</th>
                        <th>Total Rental</th>
                        <th>Downpayment</th>
                        <th>Amount Paid</th>
                        <th>Balance</th>
                        <th>Payment Status</th>
                        <th>Reservation Status</th>
                        <th>Review</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (empty($reservations)): ?>

                    <tr>
                        <td colspan="14" class="reservation-empty">
                            No reservations found.
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($reservations as $row): ?>

                        <?php
                        $tenantName = trim(
                            ($row['first_name'] ?? '') . ' ' .
                            ($row['last_name'] ?? '')
                        );

                        $endDate = getReservationEnd($row);

                        $days = (int)($row['total_days'] ?? 0);

                        if ($days <= 0 && $endDate) {
                            $days = reservationDays(
                                $row['requested_move_in'],
                                $endDate
                            );
                        }

                        $unit = $row['duration_unit'] ?? 'month';

                        $pricingLabel = $RATE_LABELS[$unit] ?? ucfirst($unit);

                        $paymentStatus = $row['payment_status'] ?? 'Unpaid';
                        ?>

                        <tr>

                            <td>
                                #<?= (int)$row['reservation_id'] ?>
                            </td>

                            <td>
                                <?= h($tenantName ?: 'Unknown Tenant') ?>
                            </td>

                            <td>
                                <?= h($row['room_number'] ?? 'N/A') ?>
                            </td>

                            <td>
                                <?= h(reservationDate(
                                    $row['requested_move_in']
                                )) ?>
                            </td>

                            <td>
                                <?= h(reservationDate($endDate)) ?>
                            </td>

                            <td>
                                <?= $days ?> days
                            </td>

                            <td>
                                <?= h($pricingLabel) ?>
                            </td>

                            <td>
                                <?= reservationMoney(
                                    $row['total_amount'] ?? 0
                                ) ?>
                            </td>

                            <td>
                                <?= reservationMoney(
                                    $row['downpayment_required'] ?? 0
                                ) ?>
                            </td>

                            <td>
                                <?= reservationMoney(
                                    $row['amount_paid'] ?? 0
                                ) ?>
                            </td>

                            <td>
                                <?= reservationMoney(
                                    $row['balance_amount'] ?? 0
                                ) ?>
                            </td>

                            <td>
                                <span class="status-badge <?= h(
                                    getStatusClass($paymentStatus)
                                ) ?>">
                                    <?= h($paymentStatus) ?>
                                </span>
                            </td>

                            <td>
                                <span class="status-badge <?= h(
                                    getStatusClass($row['status'])
                                ) ?>">
                                    <?= h($row['status']) ?>
                                </span>
                            </td>

                            <td>

                                <?php if (
                                    $row['status'] === 'Pending' &&
                                    can_access('reservations', 'edit')
                                ): ?>

                                    <div class="review-buttons">

                                        <form method="POST"
                                              class="reviewForm">

                                            <input type="hidden"
                                                   name="csrf_token"
                                                   value="<?= h(csrf_token()) ?>">

                                            <input type="hidden"
                                                   name="action"
                                                   value="review">

                                            <input type="hidden"
                                                   name="reservation_id"
                                                   value="<?= (int)$row['reservation_id'] ?>">

                                            <input type="hidden"
                                                   name="decision"
                                                   value="Approved">

                                            <button type="submit"
                                                    class="reservation-btn btn-success"
                                                    data-decision="approve">
                                                Approve
                                            </button>

                                        </form>

                                        <form method="POST"
                                              class="reviewForm">

                                            <input type="hidden"
                                                   name="csrf_token"
                                                   value="<?= h(csrf_token()) ?>">

                                            <input type="hidden"
                                                   name="action"
                                                   value="review">

                                            <input type="hidden"
                                                   name="reservation_id"
                                                   value="<?= (int)$row['reservation_id'] ?>">

                                            <input type="hidden"
                                                   name="decision"
                                                   value="Rejected">

                                            <button type="submit"
                                                    class="reservation-btn btn-danger"
                                                    data-decision="reject">
                                                Reject
                                            </button>

                                        </form>

                                    </div>

                                <?php else: ?>

                                    <span style="color:#64748b;">
                                        <?= h($row['reviewer_name'] ?? '—') ?>
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<!-- LIBRARIES -->

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /*
    |--------------------------------------------------------------------------
    | DATA FROM PHP
    |--------------------------------------------------------------------------
    */

    const reservationEvents = <?= $calendarJson ?>;

    const rates = {
        day: 500,
        week: 3000,
        month: 10000
    };

    const startInput = document.getElementById('start_date');
    const endInput = document.getElementById('end_date');

    const roomInput = document.getElementById('room_id');
    const unitInput = document.getElementById('duration_unit');

    const paidInput = document.getElementById('amount_paid');

    const totalDaysDisplay = document.getElementById(
        'total_days_display'
    );

    const totalDisplay = document.getElementById(
        'totalAmountDisplay'
    );

    const downpaymentDisplay = document.getElementById(
        'downpaymentDisplay'
    );

    const paidDisplay = document.getElementById(
        'amountPaidDisplay'
    );

    const balanceDisplay = document.getElementById(
        'balanceDisplay'
    );

    const availabilityMessage = document.getElementById(
        'availabilityMessage'
    );

    const saveButton = document.getElementById(
        'saveReservationBtn'
    );

    const reservationForm = document.getElementById(
        'reservationForm'
    );

    /*
    |--------------------------------------------------------------------------
    | FORMAT CURRENCY
    |--------------------------------------------------------------------------
    */

    function peso(amount) {
        return '₱' + Number(amount).toLocaleString('en-PH', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    /*
    |--------------------------------------------------------------------------
    | DATE DIFFERENCE
    |--------------------------------------------------------------------------
    | Uses local date-only values.
    | End date is exclusive.
    |--------------------------------------------------------------------------
    */

    function getStayDays(start, end) {

        if (!start || !end) {
            return 0;
        }

        const startDate = new Date(start + 'T00:00:00');
        const endDate = new Date(end + 'T00:00:00');

        const difference = endDate - startDate;

        return Math.round(
            difference / (1000 * 60 * 60 * 24)
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PRICING CALCULATION
    |--------------------------------------------------------------------------
    */

    function calculatePayment() {

        const start = startInput.value;
        const end = endInput.value;

        const unit = unitInput.value;
        const paid = Math.max(
            0,
            Number(paidInput.value || 0)
        );

        let days = getStayDays(start, end);

        if (days < 0) {
            days = 0;
        }

        totalDaysDisplay.value = days;

        let blocks = 0;

        if (unit === 'day') {
            blocks = days;
        } else if (unit === 'week') {
            blocks = Math.ceil(days / 7);
        } else if (unit === 'month') {
            blocks = Math.ceil(days / 30);
        }

        const total = blocks * rates[unit];

        const downpayment = total * 0.30;

        const balance = Math.max(
            0,
            total - paid
        );

        totalDisplay.textContent = peso(total);
        downpaymentDisplay.textContent = peso(downpayment);
        paidDisplay.textContent = peso(paid);
        balanceDisplay.textContent = peso(balance);

        checkAvailability();

        return {
            days: days,
            blocks: blocks,
            total: total,
            downpayment: downpayment,
            paid: paid,
            balance: balance
        };
    }

    /*
    |--------------------------------------------------------------------------
    | END DATE MINIMUM
    |--------------------------------------------------------------------------
    */

    function updateEndDateMinimum() {

        if (!startInput.value) {
            endInput.min = '';
            return;
        }

        const date = new Date(
            startInput.value + 'T00:00:00'
        );

        date.setDate(date.getDate() + 1);

        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        const minimumDate = `${year}-${month}-${day}`;

        endInput.min = minimumDate;

        if (endInput.value && endInput.value < minimumDate) {
            endInput.value = '';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ROOM AVAILABILITY CHECK
    |--------------------------------------------------------------------------
    */

    function checkAvailability() {

        const roomId = roomInput.value;
        const start = startInput.value;
        const end = endInput.value;

        if (!roomId || !start || !end) {
            availabilityMessage.textContent = '';
            availabilityMessage.style.color = '';
            saveButton.disabled = false;
            return true;
        }

        const days = getStayDays(start, end);

        if (days <= 0) {
            availabilityMessage.textContent =
                'End Date must be later than Start Date.';

            availabilityMessage.style.color = '#dc2626';
            saveButton.disabled = true;

            return false;
        }

        const conflict = reservationEvents.some(function (event) {

            const props = event.extendedProps || {};

            if (String(props.roomId) !== String(roomId)) {
                return false;
            }

            /*
             * Rejected and Cancelled reservations
             * do not block room availability.
             */

            if (!['Pending', 'Approved'].includes(props.status)) {
                return false;
            }

            /*
             * Exclusive end date overlap check.
             */

            return (
                start < event.end &&
                end > event.start
            );

        });

        if (conflict) {

            availabilityMessage.textContent =
                'This room is already reserved during the selected dates.';

            availabilityMessage.style.color = '#dc2626';

            saveButton.disabled = true;

            return false;

        }

        availabilityMessage.textContent =
            'The selected room appears available for these dates.';

        availabilityMessage.style.color = '#16a34a';

        saveButton.disabled = false;

        return true;
    }

    /*
    |--------------------------------------------------------------------------
    | INPUT LISTENERS
    |--------------------------------------------------------------------------
    */

    startInput.addEventListener('change', function () {
        updateEndDateMinimum();
        calculatePayment();
    });

    endInput.addEventListener('change', calculatePayment);

    roomInput.addEventListener('change', calculatePayment);

    unitInput.addEventListener('change', calculatePayment);

    paidInput.addEventListener('input', calculatePayment);

    /*
    |--------------------------------------------------------------------------
    | RESET FORM
    |--------------------------------------------------------------------------
    */

    if (reservationForm) {

        reservationForm.addEventListener('reset', function () {

            setTimeout(function () {

                endInput.min = '';

                totalDaysDisplay.value = 0;

                totalDisplay.textContent = peso(0);
                downpaymentDisplay.textContent = peso(0);
                paidDisplay.textContent = peso(0);
                balanceDisplay.textContent = peso(0);

                availabilityMessage.textContent = '';

                saveButton.disabled = false;

            }, 0);

        });

        /*
        |--------------------------------------------------------------------------
        | CREATE CONFIRMATION
        |--------------------------------------------------------------------------
        */

        reservationForm.addEventListener('submit', function (event) {

            event.preventDefault();

            const payment = calculatePayment();

            if (!reservationForm.reportValidity()) {
                return;
            }

            if (payment.days < 1 || payment.days > 365) {

                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Stay Duration',
                    text: 'Reservation must be between 1 and 365 days.'
                });

                return;
            }

            if (!checkAvailability()) {

                Swal.fire({
                    icon: 'error',
                    title: 'Room Not Available',
                    text: 'Please choose another room or date range.'
                });

                return;
            }

            if (payment.paid < payment.downpayment) {

                Swal.fire({
                    icon: 'warning',
                    title: 'Insufficient Downpayment',
                    text:
                        'Required 30% downpayment: ' +
                        peso(payment.downpayment)
                });

                return;
            }

            if (payment.paid > payment.total) {

                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Amount',
                    text: 'Amount received cannot exceed total rental fee.'
                });

                return;
            }

            Swal.fire({
                title: 'Save Reservation?',
                icon: 'question',
                html:
                    '<div style="text-align:left;font-size:14px;">' +
                    '<p><b>Start Date:</b> ' + startInput.value + '</p>' +
                    '<p><b>End Date:</b> ' + endInput.value + '</p>' +
                    '<p><b>Total Days:</b> ' + payment.days + '</p>' +
                    '<p><b>Total Rental:</b> ' + peso(payment.total) + '</p>' +
                    '<p><b>Required Downpayment:</b> ' +
                    peso(payment.downpayment) + '</p>' +
                    '<p><b>Amount Received:</b> ' + peso(payment.paid) + '</p>' +
                    '<p><b>Remaining Balance:</b> ' +
                    peso(payment.balance) + '</p>' +
                    '</div>',
                showCancelButton: true,
                confirmButtonText: 'Yes, Save Reservation',
                cancelButtonText: 'Cancel',
                confirmButtonColor: '#2563eb'
            }).then(function (result) {

                if (result.isConfirmed) {
                    HTMLFormElement.prototype.submit.call(
                        reservationForm
                    );
                }

            });

        });
    }

    /*
    |--------------------------------------------------------------------------
    | REVIEW CONFIRMATION
    |--------------------------------------------------------------------------
    */

    document.querySelectorAll('.reviewForm').forEach(function (form) {

        form.addEventListener('submit', function (event) {

            event.preventDefault();

            const decisionInput = form.querySelector(
                'input[name="decision"]'
            );

            const decision = decisionInput.value;

            const approve = decision === 'Approved';

            Swal.fire({
                title: approve
                    ? 'Approve Reservation?'
                    : 'Reject Reservation?',
                text: approve
                    ? 'Are you sure you want to approve this reservation?'
                    : 'Are you sure you want to reject this reservation?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: approve
                    ? 'Yes, Approve'
                    : 'Yes, Reject',
                cancelButtonText: 'Cancel',
                confirmButtonColor: approve
                    ? '#16a34a'
                    : '#dc2626'
            }).then(function (result) {

                if (result.isConfirmed) {
                    HTMLFormElement.prototype.submit.call(form);
                }

            });

        });

    });

    /*
    |--------------------------------------------------------------------------
    | FULLCALENDAR
    |--------------------------------------------------------------------------
    */

    const calendarElement = document.getElementById(
        'reservationCalendar'
    );

    if (calendarElement && typeof FullCalendar !== 'undefined') {

        const calendar = new FullCalendar.Calendar(
            calendarElement,
            {
                initialView: 'dayGridMonth',

                height: 'auto',

                events: reservationEvents,

                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listMonth'
                },

                selectable: true,

                select: function (info) {

                    if (!startInput || !endInput) {
                        return;
                    }

                    startInput.value = info.startStr;

                    /*
                     * FullCalendar's selection end is exclusive.
                     * This matches the reservation date calculation.
                     */

                    endInput.value = info.endStr;

                    updateEndDateMinimum();
                    calculatePayment();

                    if (reservationForm) {
                        reservationForm.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }

                    calendar.unselect();
                },

                eventClick: function (info) {

                    const props = info.event.extendedProps;

                    Swal.fire({
                        title: info.event.title,
                        icon: 'info',
                        html:
                            '<div style="text-align:left;font-size:14px;">' +
                            '<p><b>Tenant:</b> ' + props.tenant + '</p>' +
                            '<p><b>Room:</b> ' + props.room + '</p>' +
                            '<p><b>Start Date:</b> ' + props.start + '</p>' +
                            '<p><b>End Date:</b> ' + props.end + '</p>' +
                            '<p><b>Total Days:</b> ' + props.days + '</p>' +
                            '<p><b>Status:</b> ' + props.status + '</p>' +
                            '<hr>' +
                            '<p><b>Total Rental:</b> ' +
                            peso(props.total) + '</p>' +
                            '<p><b>Amount Paid:</b> ' +
                            peso(props.paid) + '</p>' +
                            '<p><b>Balance:</b> ' +
                            peso(props.balance) + '</p>' +
                            '<p><b>Payment Status:</b> ' +
                            props.paymentStatus + '</p>' +
                            '</div>',
                        confirmButtonText: 'Close'
                    });

                }
            }
        );

        calendar.render();
    }

    /*
    |--------------------------------------------------------------------------
    | PHP FLASH MESSAGES
    |--------------------------------------------------------------------------
    */

    const successElement = document.getElementById(
        'reservationSuccess'
    );

    const errorElement = document.getElementById(
        'reservationError'
    );

    if (successElement) {

        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: successElement.dataset.message
        });

    }

    if (errorElement) {

        Swal.fire({
            icon: 'error',
            title: 'Something Went Wrong',
            text: errorElement.dataset.message
        });

    }

    /*
    |--------------------------------------------------------------------------
    | INITIAL CALCULATION
    |--------------------------------------------------------------------------
    */

    updateEndDateMinimum();
    calculatePayment();

});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>




